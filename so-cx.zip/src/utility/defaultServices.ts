export const defaultServices = {
  IP: ["VirusTotal", "AbuseIPDB"],
  Domain: ["VirusTotal"],
  URL: ["VirusTotal"],
  Hash: ["VirusTotal"],
  Email: ["HaveIBeenPwned"],
  ASN: ["BGPToolkit"],
  MAC: ["MACVendors"]
};
